              <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                           <script>document.write(new Date().getFullYear())</script> &copy; <a href="#"> FORM-137 MANAGEMENT SYSTEM - CvSU Carmona </a>

                            </div>
                          
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

         

        </div>
        <!-- END wrapper -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->

        <!-- Vendor js -->
        <script src="../assets/js/vendor.min.js"></script>

        <!-- Plugins js-->
		
		<script src="../assets/js/lib/datatables/jquery.dataTables.min.js"></script>
        <script src="../assets/js/lib/datatables/dataTables.bootstrap5.min.js"></script>
        <script src="../assets/js/lib/datatables/dataTables.responsive.min.js"></script>
        <script src="../assets/js/lib/datatables/responsive.bootstrap5.min.js"></script>
        <script src="../assets/js/lib/datatables/dataTables.buttons.min.js"></script>
        <script src="../assets/js/lib/datatables/buttons.bootstrap5.min.js"></script>
        <script src="../assets/js/lib/datatables/buttons.html5.min.js"></script>
        <script src="../assets/js/lib/datatables/buttons.flash.min.js"></script>
        <script src="../assets/js/lib/datatables/buttons.print.min.js"></script>
        <script src="../assets/js/lib/datatables/pdfmake.min.js"></script>
        <script src="../assets/js/lib/datatables/vfs_fonts.js"></script>
        <!-- third party js ends -->
        <!-- Dashboar 1 init js-->
	
        <!-- App js-->
        <script src="../assets/js/app.min.js"></script>
        <script src="../assets/js/sweetalert2.all.min.js"></script>
        
    </body>
</html>'